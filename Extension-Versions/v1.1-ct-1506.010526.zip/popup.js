function isValidColor(color) {
  const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
  const rgbRegex = /^rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)$/;
  const rgbaRegex = /^rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*[\d.]+\s*\)$/;
  return hexRegex.test(color) || rgbRegex.test(color) || rgbaRegex.test(color);
}

function normalizeColor(color) {
  if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(color)) {
    return color;
  }
  const ctx = document.createElement('canvas').getContext('2d');
  ctx.fillStyle = color;
  return ctx.fillStyle;
}const primaryColorInput = document.getElementById('primaryColor');
const colorValue = document.getElementById('colorValue');
const darkModeToggle = document.getElementById('darkModeToggle');
const themeToggle = document.getElementById('themeToggle');
const hideCompletedToggle = document.getElementById('hideCompletedToggle');
const resetBtn = document.getElementById('resetBtn');
const resetModal = document.getElementById('resetModal');
const cancelBtn = document.getElementById('cancelBtn');
const confirmResetBtn = document.getElementById('confirmResetBtn');

let isLoadingSettings = true;

console.log('Elements loaded:', { resetBtn, resetModal, cancelBtn, confirmResetBtn });

const defaultSettings = {
  primaryColor: '#1e88e5',
  darkMode: false,
  themeEnabled: true,
  hideCompleted: false
};

function updateResetButtonColor(color) {
  resetBtn.style.backgroundColor = color;
  const confirmBtn = document.getElementById('confirmResetBtn');
  if (confirmBtn) {
    confirmBtn.style.backgroundColor = color;
  }
}

function darken(hex, percent) {
  const num = parseInt(hex.slice(1), 16);
  let r = (num >> 16) & 255;
  let g = (num >> 8) & 255;
  let b = num & 255;
  r = Math.max(0, Math.min(255, r - (r * percent / 100)));
  g = Math.max(0, Math.min(255, g - (g * percent / 100)));
  b = Math.max(0, Math.min(255, b - (b * percent / 100)));
  return "#" + (1 << 24 | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

function updateToggleColor(color) {
  const style = document.getElementById('dynamic-toggle-style') || document.createElement('style');
  style.id = 'dynamic-toggle-style';
  style.textContent = `
    .toggle-switch.active {
      background: ${color} !important;
    }
  `;
  if (!style.parentNode) {
    document.head.appendChild(style);
  }
}

function applyPopupDarkMode(enabled) {
  const divider = document.getElementById('divider');
  const resetDivider = document.getElementById('resetDivider');
  const resetBtn = document.getElementById('resetBtn');
  if (enabled) {
    document.body.classList.add('dark-mode');
    divider.style.borderTopColor = 'rgba(255, 255, 255, 0.1)';
    resetDivider.style.borderTopColor = 'rgba(255, 255, 255, 0.1)';
    resetBtn.style.color = '#fff';
  } else {
    document.body.classList.remove('dark-mode');
    divider.style.borderTopColor = 'rgba(0, 0, 0, 0.1)';
    resetDivider.style.borderTopColor = 'rgba(0, 0, 0, 0.1)';
    resetBtn.style.color = '#fff';
  }
}

function updateControlsState(themeEnabled) {
  primaryColorInput.disabled = !themeEnabled;
  primaryColorInput.style.opacity = themeEnabled ? '1' : '0.5';
  primaryColorInput.style.cursor = themeEnabled ? 'pointer' : 'not-allowed';
  
  darkModeToggle.style.opacity = themeEnabled ? '1' : '0.5';
  darkModeToggle.style.cursor = themeEnabled ? 'pointer' : 'not-allowed';
  darkModeToggle.style.pointerEvents = themeEnabled ? 'auto' : 'none';
  
  colorValue.style.opacity = themeEnabled ? '1' : '0.5';
}

function saveSettings() {
  const color = primaryColorInput.value;
  const isDarkMode = darkModeToggle.classList.contains('active');
  const isThemeEnabled = themeToggle.classList.contains('active');
  const isHideCompleted = hideCompletedToggle.classList.contains('active');

  chrome.storage.sync.set({ 
    primaryColor: color,
    darkMode: isDarkMode,
    themeEnabled: isThemeEnabled,
    hideCompleted: isHideCompleted
  });
}

chrome.storage.local.get('userSettings', (result) => {
  const savedSettings = result.userSettings || defaultSettings;
  const savedColor = savedSettings.primaryColor || defaultSettings.primaryColor;
  const savedDarkMode = savedSettings.darkMode !== undefined ? savedSettings.darkMode : defaultSettings.darkMode;
  const savedThemeEnabled = savedSettings.themeEnabled !== undefined ? savedSettings.themeEnabled : defaultSettings.themeEnabled;
  const savedHideCompleted = savedSettings.hideCompleted !== undefined ? savedSettings.hideCompleted : defaultSettings.hideCompleted;
  
  primaryColorInput.value = savedColor;
  colorValue.textContent = savedColor;
  updateToggleColor(savedColor);
  updateResetButtonColor(savedColor);

  if (savedDarkMode) {
    darkModeToggle.classList.add('active');
  } else {
    darkModeToggle.classList.remove('active');
  }
  
  if (savedThemeEnabled) {
    themeToggle.classList.add('active');
  } else {
    themeToggle.classList.remove('active');
  }

  if (savedHideCompleted) {
    hideCompletedToggle.classList.add('active');
  } else {
    hideCompletedToggle.classList.remove('active');
  }
  
  updateControlsState(savedThemeEnabled);
  applyPopupDarkMode(savedDarkMode);
  
  isLoadingSettings = false;
});

primaryColorInput.addEventListener('input', (e) => {
  const color = e.target.value;
  colorValue.textContent = color;
  updateToggleColor(color);
  updateResetButtonColor(color);

  if (!isLoadingSettings) {
    chrome.storage.local.set({ userSettings: { ...getCurrentSettings(), primaryColor: color } });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'applyPrimaryColor',
          color: color
        }).catch(() => {});
      }
    });
  }
});

function getCurrentSettings() {
  return {
    primaryColor: primaryColorInput.value,
    darkMode: darkModeToggle.classList.contains('active'),
    themeEnabled: themeToggle.classList.contains('active'),
    hideCompleted: hideCompletedToggle.classList.contains('active')
  };
}

darkModeToggle.addEventListener('click', () => {
  if (isLoadingSettings) return;
  
  const isActive = darkModeToggle.classList.toggle('active');
  applyPopupDarkMode(isActive);

  chrome.storage.local.set({ userSettings: { ...getCurrentSettings(), darkMode: isActive } });
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'applyDarkMode',
        enabled: isActive
      }).catch(() => {});
    }
  });
});

themeToggle.addEventListener('click', () => {
  if (isLoadingSettings) return;
  
  const isActive = themeToggle.classList.toggle('active');
  updateControlsState(isActive);

  chrome.storage.local.set({ userSettings: { ...getCurrentSettings(), themeEnabled: isActive } });
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      if (isActive) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'toggleTheme',
          enabled: isActive
        }).catch(() => {});
      } else {
        chrome.tabs.reload(tabs[0].id);
      }
    }
  });
});

hideCompletedToggle.addEventListener('click', () => {
  if (isLoadingSettings) return;
  
  const isActive = hideCompletedToggle.classList.toggle('active');

  chrome.storage.local.set({ userSettings: { ...getCurrentSettings(), hideCompleted: isActive } });
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'toggleHideCompleted',
        enabled: isActive
      }).catch(() => {});
    }
  });
});

if (resetBtn) {
  resetBtn.addEventListener('click', () => {
    console.log('Reset button clicked');
    if (resetModal) {
      resetModal.classList.add('active');
    } else {
      console.error('resetModal not found');
    }
  });
} else {
  console.error('resetBtn not found');
}

if (cancelBtn) {
  cancelBtn.addEventListener('click', () => {
    console.log('Cancel button clicked');
    resetModal.classList.remove('active');
  });
}

if (confirmResetBtn) {
  confirmResetBtn.addEventListener('click', () => {
    console.log('Confirm reset clicked');
    chrome.storage.local.set({ userSettings: defaultSettings }, () => {
      primaryColorInput.value = defaultSettings.primaryColor;
      colorValue.textContent = defaultSettings.primaryColor;
      updateToggleColor(defaultSettings.primaryColor);
      updateResetButtonColor(defaultSettings.primaryColor);
      
      darkModeToggle.classList.remove('active');
      themeToggle.classList.add('active');
      hideCompletedToggle.classList.remove('active');
      
      updateControlsState(true);
      applyPopupDarkMode(false);
      
      resetModal.classList.remove('active');
      
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    });
  });
}