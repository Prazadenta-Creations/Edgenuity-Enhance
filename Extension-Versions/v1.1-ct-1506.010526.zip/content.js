const state = {
  color: "#1e88e5",
  darkMode: false,
  enabled: true,
  hideCompleted: false
};

async function saveSettings(obj) {
  return new Promise(res => {
    chrome.storage.local.get('userSettings', (data) => {
      const currentSettings = data.userSettings || {};
      const newSettings = { ...currentSettings, ...obj };
      chrome.storage.local.set({ userSettings: newSettings }, res);
    });
  });
}

function loadSettings() {
  return new Promise(res => {
    chrome.storage.local.get('userSettings', (data) => {
      const settings = data.userSettings || {};
      state.color = settings.primaryColor ?? "#1e88e5";
      state.darkMode = settings.darkMode ?? false;
      state.enabled = settings.themeEnabled ?? true;
      state.hideCompleted = settings.hideCompleted ?? false;
      res();
    });
  });
}

function debounce(fn, delay) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

function darken(hex, percent) {
  const num = parseInt(hex.slice(1), 16);
  let r = (num >> 16) & 255;
  let g = (num >> 8) & 255;
  let b = num & 255;
  r = Math.max(0, Math.min(255, r - (r * percent / 100)));
  g = Math.max(0, Math.min(255, g - (g * percent / 100)));
  b = Math.max(0, Math.min(255, b - (b * percent / 100)));
  return "#" + (1 << 24 | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

function hexToRgb(hex) {
  const num = parseInt(hex.slice(1), 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

async function safeFetchLogo(src, attempts = 3) {
  for (let i = 0; i < attempts; i++) {
    try {
      const response = await fetch(src);
      if (response.ok) return await response.text();
    } catch {}
    await new Promise(r => setTimeout(r, 500));
  }
  return null;
}

async function replaceLogoWithSvg(logoImg, color) {
  try {
    const svgText = await safeFetchLogo(logoImg.src);
    if (!svgText) return;
    const wrapper = document.createElement("div");
    wrapper.innerHTML = svgText;
    const svg = wrapper.querySelector("svg");
    if (svg) {
      const computedStyle = window.getComputedStyle(logoImg);
      svg.style.width = logoImg.offsetWidth + "px";
      svg.style.height = logoImg.offsetHeight + "px";
      svg.style.display = computedStyle.display;
      svg.style.position = computedStyle.position;
      svg.style.margin = computedStyle.margin;
      svg.style.padding = computedStyle.padding;
      svg.style.verticalAlign = computedStyle.verticalAlign;
      svg.querySelectorAll("path, circle, rect, polygon, ellipse, line, polyline")
        .forEach(el => el.setAttribute("fill", color));
      svg.removeAttribute("fill");
      svg.setAttribute("fill", color);
      svg.className = logoImg.className;
      logoImg.replaceWith(svg);
      window.edgenuitySvg = svg;
    }
  } catch (err) {
  }
}

async function setFaviconFromExtension(color) {
  try {
    const url = chrome.runtime.getURL("favicon.svg");
    const response = await fetch(url);
    let svgText = await response.text();
    
    const parser = new DOMParser();
    const svgDoc = parser.parseFromString(svgText, "image/svg+xml");
    const svgElement = svgDoc.querySelector("svg");
    
    if (svgElement) {
      const coloredRect = svgElement.querySelector("rect[mask]");
      if (coloredRect) {
        coloredRect.setAttribute("fill", color);
      }
      
      const serializer = new XMLSerializer();
      const modifiedSvg = serializer.serializeToString(svgElement);
      const dataUrl = "data:image/svg+xml," + encodeURIComponent(modifiedSvg);
      
      let link = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = dataUrl;
    }
  } catch (err) {
  }
}

function removeTheme() {
  document.querySelectorAll("svg").forEach(svg => {
    svg.style.color = "";
  });

  const profileBtn = document.querySelector("button.profile-button#profile-nav-dropdown");
  if (profileBtn) {
    profileBtn.style.backgroundColor = "";
    profileBtn.style.borderColor = "";
    profileBtn.style.color = "";
    profileBtn.style.transition = "";
  }

  document.querySelectorAll(".container-progress .student-progress.current-progress")
    .forEach(bar => {
      bar.style.backgroundColor = "";
      bar.style.borderColor = "";
    });

  document.querySelectorAll(".container-progress .student-progress.target-progress")
    .forEach(marker => {
      marker.style.borderColor = "";
      marker.style.backgroundColor = "";
    });

  document.querySelectorAll("a.btn-primary.enrollment-card-btn-next, a.btn-primary.enrollment-card-btn-prev, a.btn-primary.enrollment-card-btn-start")
    .forEach(btn => {
      btn.style.backgroundColor = "";
      btn.style.borderColor = "";
      btn.style.color = "";
      btn.style.transition = "";
      btn.onmouseenter = null;
      btn.onmouseleave = null;
    });

  if (window.edgenuitySvg) {
    window.edgenuitySvg.querySelectorAll("path, circle, rect, polygon, ellipse, line, polyline")
      .forEach(el => {
        el.setAttribute("fill", "");
        el.style.fill = "";
      });
    window.edgenuitySvg.setAttribute("fill", "");
  }

  document.querySelectorAll(".document-icon svg path, .document-icon svg rect, .document-icon svg circle")
    .forEach(el => {
      el.setAttribute("fill", "");
      el.style.fill = "";
    });
  document.querySelectorAll(".document-icon")
    .forEach(icon => {
      icon.style.color = "";
    });

  const styleTag = document.getElementById("primary-footer-style");
  if (styleTag) {
    styleTag.remove();
  }

  const link = document.querySelector("link[rel~='icon']");
  if (link) {
    link.href = "";
  }

  applyDarkMode(false);
}

async function applyPrimary(color) {
  try {
    document.querySelectorAll("svg").forEach(svg => {
      svg.style.color = color;
    });

    const profileBtn = document.querySelector("button.profile-button#profile-nav-dropdown");
    if (profileBtn) {
      profileBtn.style.backgroundColor = color;
      profileBtn.style.borderColor = color;
      profileBtn.style.color = "#e1e1e1";
      profileBtn.style.transition = "none";
    }

    document.querySelectorAll(".container-progress .student-progress.current-progress")
      .forEach(bar => {
        bar.style.backgroundColor = color;
        bar.style.borderColor = color;
      });

    document.querySelectorAll(".container-progress .student-progress.target-progress")
      .forEach(marker => {
        marker.style.borderColor = "#000";
        marker.style.backgroundColor = "transparent";
      });

    document.querySelectorAll("a.btn-primary.enrollment-card-btn-next, a.btn-primary.enrollment-card-btn-prev, a.btn-primary.enrollment-card-btn-start")
      .forEach(btn => {
        btn.style.backgroundColor = color;
        btn.style.borderColor = color;
        btn.style.color = "#fff";
        btn.style.transition = "none";
        btn.onmouseenter = () => {
          btn.style.backgroundColor = darken(color, 20);
          btn.style.borderColor = darken(color, 20);
        };
        btn.onmouseleave = () => {
          btn.style.backgroundColor = color;
          btn.style.borderColor = color;
        };
      });

    const logoImg = document.querySelector("img.edgenuity-logo");
    if (logoImg && !window.edgenuitySvg) {
      logoImg.addEventListener("load", () => replaceLogoWithSvg(logoImg, color));
      if (logoImg.complete) replaceLogoWithSvg(logoImg, color);
    }
    
    if (window.edgenuitySvg) {
      window.edgenuitySvg.querySelectorAll("path, circle, rect, polygon, ellipse, line, polyline")
        .forEach(el => {
          el.setAttribute("fill", color);
          el.style.fill = color;
        });
      window.edgenuitySvg.setAttribute("fill", color);
    }

    document.querySelectorAll("img.course-logo-bug").forEach(img => {
      img.remove();
    });

    document.querySelectorAll(".document-icon svg path, .document-icon svg rect, .document-icon svg circle")
      .forEach(el => {
        el.setAttribute("fill", color);
        el.style.fill = color;
      });
    document.querySelectorAll(".document-icon")
      .forEach(icon => {
        icon.style.color = color;
      });

    const styleTag = document.getElementById("primary-footer-style") || document.createElement("style");
    styleTag.id = "primary-footer-style";
    styleTag.textContent = `
      .footer a:link,
      .footer a:visited {
        color: ${color} !important;
        font-weight: 700;
        text-decoration: underline;
        text-underline-offset: 2.3px;
        border-color: ${color} !important;
        transition: none;
      }
      .footer a:hover {
        color: ${darken(color, 20)} !important;
        border-color: ${darken(color, 20)} !important;
      }
    `;
    document.head.appendChild(styleTag);

    await setFaviconFromExtension(color);
  } catch (error) {
  }
}

function applyDarkMode(enabled) {
  const bg = document.querySelector(".home-page-background");
  const nav = document.querySelector("nav.navbar.edgenuity");
  const cards = document.querySelectorAll(".sle-card.card");
  const titles = document.querySelectorAll(".card-title.course-title a.link-nostyle");
  const subjects = document.querySelectorAll(".card-subject");
  const progressLabels = document.querySelectorAll(".progress-label");
  const courseGrades = document.querySelectorAll(".course-grade-text, .course-grade-label");
  const footerCopyright = document.querySelectorAll(".float-left-50-width");

  if (enabled) {
    if (bg) bg.style.backgroundColor = "#121212";
    if (nav) {
      nav.style.backgroundColor = "#1f1f1f";
      nav.style.boxShadow = "0 2px 10px rgba(0,0,0,0.6)";
      nav.style.borderBottom = "none";
    }

    cards.forEach(card => {
      card.style.backgroundColor = "#1f1f1f";
      card.style.boxShadow = "0 0 8px rgba(0,0,0,0.8)";
      card.style.border = "none";
      card.style.color = "#fff";
    });

    titles.forEach(title => {
      title.style.color = "#e1e1e1";
    });

    subjects.forEach(subject => {
      subject.style.color = "#adadad";
    });

    progressLabels.forEach(label => {
      label.style.color = "#adadad";
    });

    courseGrades.forEach(el => {
      el.style.color = "#e1e1e1";
    });

    footerCopyright.forEach(el => {
      el.style.color = "#adadad";
    });

  } else {
    if (bg) bg.style.backgroundColor = "";
    if (nav) {
      nav.style.backgroundColor = "";
      nav.style.boxShadow = "";
      nav.style.borderBottom = "";
    }

    cards.forEach(card => {
      card.style.backgroundColor = "";
      card.style.boxShadow = "";
      card.style.border = "";
      card.style.color = "";
    });

    titles.forEach(title => {
      title.style.color = "";
    });

    subjects.forEach(subject => {
      subject.style.color = "";
    });

    progressLabels.forEach(label => {
      label.style.color = "";
    });

    courseGrades.forEach(el => {
      el.style.color = "";
    });

    footerCopyright.forEach(el => {
      el.style.color = "";
    });
  }
  
  const dividers = document.querySelectorAll("li.nav-item.drawer-action-btn.divider");
  dividers.forEach(divider => {
    divider.style.setProperty('color', '#adadad', 'important');
  });
}

function applyTheme() {
  if (!state.enabled) return;
  applyPrimary(state.color);
  applyDarkMode(state.darkMode);
}

const applyThemeDebounced = debounce(() => applyTheme(), 120);

function toggleHideCompleted() {
  chrome.storage.local.get('userSettings', (data) => {
    const settings = data.userSettings || {};
    const isHidden = settings.hideCompleted === true;
    const newState = !isHidden;
    
    chrome.storage.local.set({ userSettings: { ...settings, hideCompleted: newState } }, () => {
      if (newState) {
        hideCompletedCourses();
      } else {
        showCompletedCourses();
      }
    });
  });
}

function hideCompletedCourses() {
  document.querySelectorAll(".sle-card.card").forEach(card => {
    const completedBtn = card.querySelector(".enrollment-card-btn-next[title='Completed']");
    if (completedBtn) {
      card.parentElement.style.display = "none";
    }
  });
}

function showCompletedCourses() {
  document.querySelectorAll(".sle-card.card").forEach(card => {
    card.parentElement.style.display = "";
  });
}

(async function init() {
  await loadSettings();
  if (state.enabled) {
    applyTheme();
  }

  setTimeout(applyTheme, 300);

  chrome.storage.local.get('userSettings', (data) => {
    if (data.userSettings?.hideCompleted === true) {
      hideCompletedCourses();
    }
  });

  new MutationObserver(() => {
    applyThemeDebounced();
    chrome.storage.local.get('userSettings', (data) => {
      if (data.userSettings?.hideCompleted === true) hideCompletedCourses();
    });
  }).observe(document.body, {
    childList: true,
    subtree: true
  });
})();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.action === "applyPrimaryColor") {
      state.color = msg.color;
      await saveSettings({ primaryColor: state.color });
      applyPrimary(state.color);
    }
    if (msg.action === "applyDarkMode") {
      state.darkMode = msg.enabled;
      await saveSettings({ darkMode: state.darkMode });
      applyDarkMode(state.darkMode);
    }
    if (msg.action === "toggleTheme") {
      state.enabled = msg.enabled;
      await saveSettings({ themeEnabled: state.enabled });
      if (state.enabled) applyTheme();
      else removeTheme();
    }
    if (msg.action === "toggleHideCompleted") {
      await saveSettings({ hideCompleted: msg.enabled });
      if (msg.enabled) hideCompletedCourses();
      else showCompletedCourses();
    }
    
    sendResponse({ success: true });
  })();
  return true;
});